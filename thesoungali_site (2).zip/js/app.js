// Fichier: js/app.js
window.addEventListener('DOMContentLoaded',()=>{
  try{
    const canvasWrap = document.getElementById('bg-canvas');
    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(60,window.innerWidth/window.innerHeight,0.1,1000);
    camera.position.z = 40;
    const renderer = new THREE.WebGLRenderer({antialias:true,alpha:true});
    renderer.setSize(window.innerWidth,window.innerHeight);
    canvasWrap.appendChild(renderer.domElement);

    const geom = new THREE.BufferGeometry();
    const count = 1200;
    const positions = new Float32Array(count * 3);
    for(let i=0;i<count*3;i++) positions[i] = (Math.random()-0.5)*120;
    geom.setAttribute('position', new THREE.BufferAttribute(positions,3));
    const mat = new THREE.PointsMaterial({size:0.6,transparent:true,opacity:0.9});
    const points = new THREE.Points(geom, mat);
    scene.add(points);

    function onResize(){
      camera.aspect = window.innerWidth/window.innerHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(window.innerWidth,window.innerHeight);
    }
    window.addEventListener('resize', onResize);

    let t=0; function animate(){
      t += 0.002;
      points.rotation.y = t*0.6;
      points.rotation.x = Math.sin(t)*0.1;
      renderer.render(scene,camera);
      requestAnimationFrame(animate);
    }
    animate();

    window.addEventListener('mousemove',(e)=>{
      const x = (e.clientX/window.innerWidth - 0.5)*2;
      const y = (e.clientY/window.innerHeight - 0.5)*2;
      camera.position.x += (x*10 - camera.position.x)*0.05;
      camera.position.y += (-y*6 - camera.position.y)*0.05;
    });
  }catch(err){console.warn('Three.js non dispo',err)}

  const conversation = document.getElementById('conversation');
  const form = document.getElementById('ai-form');
  const input = document.getElementById('ai-input');

  function appendLine(text,who='bot'){
    const el = document.createElement('div');
    el.className = 'line ' + who;
    el.textContent = text;
    conversation.appendChild(el);
    conversation.scrollTop = conversation.scrollHeight;
  }

  form.addEventListener('submit',e=>{
    const q = input.value.trim(); if(!q) return;
    appendLine(q,'user'); input.value='';
    setTimeout(()=>{
      if(/poème|poeme|poesie/i.test(q)){
        appendLine("Voici un petit poème:\nRien n'est plus beau qu'un sourire,\nLumière née d'un coeur — Soungali.", 'bot');
      } else if(/couleur|theme|thème/i.test(q)){
        appendLine('Tu peux changer le thème avec le bouton "Thème" en haut.', 'bot');
      } else if(/présentation|qui es-tu|toi/i.test(q)){
        appendLine('Je suis l\'assistant prototype de thesoungali.site — prototype JS.', 'bot');
      } else {
        appendLine('Réponse prototype : ' + q.split('').reverse().join(''), 'bot');
      }
    }, 700 + Math.random()*600);
  });

  const themeBtn = document.getElementById('theme-toggle');
  let dark = true;
  themeBtn.addEventListener('click',()=>{
    dark = !dark;
    if(dark){document.documentElement.style.setProperty('--bg','#06070a');}
    else{document.documentElement.style.setProperty('--bg','#f7faff');}
    document.body.classList.toggle('light');
  });
});
