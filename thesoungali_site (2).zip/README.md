# thesoungali.site — Projet statique
Fichiers prêts pour GitHub Pages.
## Déploiement rapide
1. Crée un dépôt GitHub public (ex : `thesoungali.site`).
2. Téléverse tous les fichiers et dossiers du projet à la racine du dépôt.
3. Active Pages dans `Settings → Pages` : Branch: main et dossier / (root).
4. Configure DNS :
   - A records -> 185.199.108.153, 185.199.109.153, 185.199.110.153, 185.199.111.153
   - CNAME www -> USERNAME.github.io
5. Active Enforce HTTPS.
